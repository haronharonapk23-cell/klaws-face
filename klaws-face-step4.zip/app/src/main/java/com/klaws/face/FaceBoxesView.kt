package com.klaws.face

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

/** Dessine des cadres rouges numérotés sur les visages détectés (image affichée en fitCenter, padding 4dp). */
class FaceBoxesView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var boxes: List<Rect> = emptyList()
    private var imgW = 0
    private var imgH = 0

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFD50000.toInt()
        strokeWidth = 4f * resources.displayMetrics.density
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFD50000.toInt()
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textSize = 14f * resources.displayMetrics.scaledDensity
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }

    fun setFaces(list: List<Rect>, w: Int, h: Int) {
        boxes = list
        imgW = w
        imgH = h
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (imgW <= 0 || imgH <= 0) return
        val pad = 4f * resources.displayMetrics.density
        val aw = width - 2 * pad
        val ah = height - 2 * pad
        val scale = min(aw / imgW, ah / imgH)
        val ox = (width - imgW * scale) / 2f
        val oy = (height - imgH * scale) / 2f
        val r = 11f * resources.displayMetrics.density
        for ((i, b) in boxes.withIndex()) {
            val l = ox + b.left * scale
            val t = oy + b.top * scale
            canvas.drawRect(l, t, ox + b.right * scale, oy + b.bottom * scale, stroke)
            canvas.drawCircle(l + r, t + r, r, fill)
            canvas.drawText((i + 1).toString(), l + r, t + r + txt.textSize / 3f, txt)
        }
    }
}
