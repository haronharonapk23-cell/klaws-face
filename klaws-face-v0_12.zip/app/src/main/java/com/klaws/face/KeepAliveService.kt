package com.klaws.face

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.content.ContextCompat

/**
 * Service au premier plan : il garde le processus vivant (notification + CPU éveillé)
 * pendant le traitement d'une vidéo, même si l'utilisateur quitte l'app pour Facebook, TikTok, etc.
 * Le calcul lui-même reste dans le thread de MainActivity.
 */
class KeepAliveService : Service() {

    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null && intent.action == ACTION_CANCEL) {
            cancelRequested = true
            if (!running) stopSelf()
            return START_NOT_STICKY
        }
        ensureChannel(this)
        val n = build(this, getString(R.string.notif_starting), 0, 0, true)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, n)
        }
        try {
            if (wake == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "klaws:video")
                w.setReferenceCounted(false)
                w.acquire(3L * 60L * 60L * 1000L)
                wake = w
            }
        } catch (e: Throwable) {
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try {
            val w = wake
            if (w != null && w.isHeld) w.release()
        } catch (e: Throwable) {
        }
        wake = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_CANCEL = "com.klaws.face.CANCEL_VIDEO"
        private const val CHANNEL = "klaws_video"
        private const val NOTIF_ID = 4201
        private const val DONE_ID = 4202

        @Volatile var cancelRequested = false
        @Volatile var running = false
        @Volatile private var generation = 0

        fun start(ctx: Context) {
            generation++
            cancelRequested = false
            running = true
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, KeepAliveService::class.java))
            } catch (e: Throwable) {
                running = false
            }
        }

        /** Arrêt légèrement différé : évite une erreur système si le traitement échoue dès la première seconde. */
        fun stop(ctx: Context) {
            running = false
            val gen = generation
            Handler(Looper.getMainLooper()).postDelayed({
                if (gen == generation && !running) {
                    try { ctx.stopService(Intent(ctx, KeepAliveService::class.java)) } catch (e: Throwable) { }
                }
            }, 1500L)
        }

        fun update(ctx: Context, text: String, done: Int, total: Int) {
            if (!running) return
            try {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(NOTIF_ID, build(ctx, text, done, total, true))
            } catch (e: Throwable) {
            }
        }

        fun notifyDone(ctx: Context, text: String) {
            try {
                ensureChannel(ctx)
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(DONE_ID, build(ctx, text, 0, 0, false))
            } catch (e: Throwable) {
            }
        }

        private fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL) == null) {
                val ch = NotificationChannel(CHANNEL, ctx.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
                nm.createNotificationChannel(ch)
            }
        }

        private fun build(ctx: Context, text: String, done: Int, total: Int, ongoing: Boolean): Notification {
            val openIntent = Intent(ctx, MainActivity::class.java)
            openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val open = PendingIntent.getActivity(
                ctx, 0, openIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val b = Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle(ctx.getString(R.string.app_name))
                .setContentText(text)
                .setContentIntent(open)
                .setOnlyAlertOnce(true)
                .setOngoing(ongoing)
            if (ongoing) {
                b.setProgress(total, done, total <= 0)
                val cancelIntent = Intent(ctx, KeepAliveService::class.java)
                cancelIntent.action = ACTION_CANCEL
                val cancel = PendingIntent.getService(
                    ctx, 1, cancelIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                b.addAction(
                    Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel,
                        ctx.getString(R.string.video_cancel),
                        cancel
                    ).build()
                )
            } else {
                b.setAutoCancel(true)
            }
            return b.build()
        }
    }
}
