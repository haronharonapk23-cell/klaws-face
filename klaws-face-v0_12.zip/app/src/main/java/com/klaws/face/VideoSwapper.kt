package com.klaws.face

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import java.io.FileDescriptor
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** maxSide : plus grand côté de la vidéo de sortie (1920 = 1080p). maxFps : images/seconde maximum. */
class VideoOptions(val maxSide: Int, val maxFps: Int, val enhance: Boolean, val enhanceEvery: Int = 1)

class VideoReport(
    val total: Int,
    val swapped: Int,
    val tracked: Int,
    val noFace: Int,
    val preview: Bitmap?,
    val enhanceStatus: String,
    val trimmed: Boolean
)

class CancelledException : RuntimeException("cancelled")
class NoFaceException : RuntimeException("no face in video")

/** Écrit une vidéo MP4 (H.264) image par image, puis recopie le son d'origine sans le recompresser. */
class Mp4Writer(
    fd: FileDescriptor,
    private val w: Int,
    private val h: Int,
    fps: Int,
    private val audioFmt: MediaFormat?
) {
    private val muxer = MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val enc: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
    private val info = MediaCodec.BufferInfo()
    private val argb = IntArray(w * h)
    private var vTrack = -1
    var aTrack = -1
        private set
    private var started = false
    private var lastPts = 0L

    init {
        val bitrate = (w.toLong() * h * fps * 0.14).toLong().coerceIn(3_000_000L, 30_000_000L).toInt()
        val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
        f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        f.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
        f.setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
        enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
    }

    /** bmp doit avoir exactement la taille w x h. */
    fun addFrame(bmp: Bitmap, ptsUs: Long) {
        bmp.getPixels(argb, 0, w, 0, 0, w, h)
        var idx: Int
        while (true) {
            idx = enc.dequeueInputBuffer(10_000)
            if (idx >= 0) break
            drain(false)
        }
        val img = enc.getInputImage(idx) ?: throw IllegalStateException("encoder input image unavailable")
        fill(img)
        enc.queueInputBuffer(idx, 0, w * h * 3 / 2, ptsUs, 0)
        lastPts = ptsUs
        drain(false)
    }

    private fun fill(img: Image) {
        val yP = img.planes[0]
        val uP = img.planes[1]
        val vP = img.planes[2]
        val yB = yP.buffer
        val uB = uP.buffer
        val vB = vP.buffer
        val yRow = yP.rowStride
        val uRow = uP.rowStride
        val vRow = vP.rowStride
        val uPix = uP.pixelStride
        val vPix = vP.pixelStride
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val p00 = argb[y * w + x]
                val p01 = argb[y * w + x + 1]
                val p10 = argb[(y + 1) * w + x]
                val p11 = argb[(y + 1) * w + x + 1]
                var rs = 0
                var gs = 0
                var bs = 0
                for (k in 0 until 4) {
                    val p = when (k) { 0 -> p00; 1 -> p01; 2 -> p10; else -> p11 }
                    val r = (p shr 16) and 255
                    val g = (p shr 8) and 255
                    val b = p and 255
                    rs += r; gs += g; bs += b
                    val yy = ((47 * r + 157 * g + 16 * b + 128) shr 8) + 16
                    val dx = k and 1
                    val dy = k shr 1
                    yB.put((y + dy) * yRow + x + dx, yy.coerceIn(16, 235).toByte())
                }
                val r = rs shr 2
                val g = gs shr 2
                val b = bs shr 2
                val u = ((-26 * r - 87 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 102 * g - 10 * b + 128) shr 8) + 128
                uB.put((y / 2) * uRow + (x / 2) * uPix, u.coerceIn(16, 240).toByte())
                vB.put((y / 2) * vRow + (x / 2) * vPix, v.coerceIn(16, 240).toByte())
                x += 2
            }
            y += 2
        }
    }

    private fun drain(eos: Boolean) {
        var idle = 0
        while (true) {
            val oi = enc.dequeueOutputBuffer(info, if (eos) 10_000L else 0L)
            if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!eos) return
                idle++
                if (idle > 1000) throw IllegalStateException("encoder timeout")
                continue
            }
            if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                vTrack = muxer.addTrack(enc.outputFormat)
                val af = audioFmt
                if (af != null) {
                    aTrack = try { muxer.addTrack(af) } catch (e: Exception) { -1 }
                }
                muxer.start()
                started = true
                continue
            }
            if (oi < 0) continue
            idle = 0
            val buf = enc.getOutputBuffer(oi)
            if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
            if (info.size > 0 && buf != null && started) {
                buf.position(info.offset)
                buf.limit(info.offset + info.size)
                muxer.writeSampleData(vTrack, buf, info)
            }
            enc.releaseOutputBuffer(oi, false)
            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
        }
    }

    fun finishVideo() {
        var idx: Int
        while (true) {
            idx = enc.dequeueInputBuffer(10_000)
            if (idx >= 0) break
            drain(false)
        }
        enc.queueInputBuffer(idx, 0, 0, lastPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        drain(true)
    }

    /** Recopie la piste audio telle quelle (sans recompression), limitée à la durée traitée. */
    fun copyAudio(context: Context, uri: Uri, audioIndex: Int, maxUs: Long) {
        if (aTrack < 0 || !started) return
        val ex = MediaExtractor()
        try {
            ex.setDataSource(context, uri, null)
            ex.selectTrack(audioIndex)
            ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            var cap = 262144
            val f = ex.getTrackFormat(audioIndex)
            if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                cap = max(cap, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
            }
            val buf = ByteBuffer.allocate(cap)
            val bi = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (t < 0 || t > maxUs) break
                val flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                bi.set(0, size, t, flags)
                muxer.writeSampleData(aTrack, buf, bi)
                ex.advance()
            }
        } finally {
            ex.release()
        }
    }

    fun close() {
        try { enc.stop() } catch (e: Exception) { }
        try { enc.release() } catch (e: Exception) { }
        try { muxer.stop() } catch (e: Exception) { }
        try { muxer.release() } catch (e: Exception) { }
    }

    fun abort() {
        try { enc.stop() } catch (e: Exception) { }
        try { enc.release() } catch (e: Exception) { }
        try { muxer.release() } catch (e: Exception) { }
    }
}

object VideoSwapper {

    const val MAX_SECONDS = 90
    private const val MAX_VIDEO_FACES = 2

    /** Suivi indépendant des deux personnes dans la vidéo. */
    private data class FaceTrack(var box: Rect, var kps: FloatArray, var lost: Int = 0)

    private fun getFrame(r: MediaMetadataRetriever, tUs: Long, w: Int = 0, h: Int = 0): Bitmap? {
        var b: Bitmap? = null
        // Décodage directement à la taille de sortie (beaucoup plus rapide qu'en pleine résolution)
        if (w > 0 && h > 0 && android.os.Build.VERSION.SDK_INT >= 27) {
            try { b = r.getScaledFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST, w, h) } catch (e: Exception) { }
        }
        if (b != null) return b
        try { b = r.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST) } catch (e: Exception) { }
        if (b == null) {
            try { b = r.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) } catch (e: Exception) { }
        }
        return b
    }

    private fun fit(src: Bitmap, ow: Int, oh: Int): Bitmap {
        var b = src
        if (b.config == Bitmap.Config.HARDWARE) {
            val c = b.copy(Bitmap.Config.ARGB_8888, true)
            b.recycle()
            b = c ?: throw IllegalStateException("frame copy failed")
        }
        if (b.width == ow && b.height == oh) return b
        val s = Bitmap.createScaledBitmap(b, ow, oh, true)
        if (s !== b) b.recycle()
        return s
    }

    private fun frameRateOf(f: MediaFormat): Int {
        return try {
            f.getInteger(MediaFormat.KEY_FRAME_RATE)
        } catch (e: Exception) {
            try { f.getFloat(MediaFormat.KEY_FRAME_RATE).toInt() } catch (e2: Exception) { 30 }
        }
    }

    /** Si le téléphone est trop chaud, attend un peu : le processeur reste rapide au lieu de ralentir de lui-même. */
    private fun thermalWait(context: Context, cancelled: () -> Boolean, onPause: (Boolean) -> Unit) {
        if (android.os.Build.VERSION.SDK_INT < 29) return
        val pm = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager ?: return
        var paused = false
        var waited = 0
        while (pm.currentThermalStatus >= android.os.PowerManager.THERMAL_STATUS_SEVERE && waited < 90) {
            if (cancelled()) throw CancelledException()
            if (!paused) {
                paused = true
                onPause(true)
            }
            Thread.sleep(3000L)
            waited += 3
        }
        if (paused) onPause(false)
    }

    fun process(
        context: Context,
        swapper: FaceSwapper,
        videoUri: Uri,
        latent: FloatArray,
        opts: VideoOptions,
        outFd: FileDescriptor,
        onProgress: (Int, Int) -> Unit,
        cancelled: () -> Boolean,
        onPause: (Boolean) -> Unit = { }
    ): VideoReport {
        val mmr = MediaMetadataRetriever()
        mmr.setDataSource(context, videoUri)
        var writer: Mp4Writer? = null
        var lastRaw: Bitmap? = null
        try {
            val durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (durMs <= 0L) throw IllegalStateException("video duration unknown")

            // fps source + piste audio
            var srcFps = 30
            var audioIdx = -1
            var audioFmt: MediaFormat? = null
            val ex = MediaExtractor()
            try {
                ex.setDataSource(context, videoUri, null)
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("video/") && f.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        srcFps = frameRateOf(f)
                    }
                    if (mime.startsWith("audio/") && audioIdx < 0) {
                        audioIdx = i
                        audioFmt = f
                    }
                }
            } catch (e: Exception) {
            } finally {
                ex.release()
            }

            val fps = min(srcFps.coerceIn(5, 60), opts.maxFps)
            val durUs = min(durMs, MAX_SECONDS * 1000L) * 1000L
            val trimmed = durMs > MAX_SECONDS * 1000L + 500L
            val total = (durUs * fps / 1_000_000L).toInt().coerceAtLeast(1)

            val first = getFrame(mmr, 0L) ?: throw IllegalStateException("cannot read video frames")
            val sc = min(1f, opts.maxSide.toFloat() / max(first.width, first.height))
            val ow = max(16, ((first.width * sc).toInt() / 16) * 16)
            val oh = max(16, ((first.height * sc).toInt() / 16) * 16)
            first.recycle()

            val wr = Mp4Writer(outFd, ow, oh, fps, audioFmt)
            writer = wr

            var angle = 0
            var missRun = 0
            val tracks = arrayOfNulls<FaceTrack>(MAX_VIDEO_FACES)
            var swapped = 0
            var tracked = 0
            var noFace = 0
            var preview: Bitmap? = null

            for (i in 0 until total) {
                if (cancelled()) throw CancelledException()
                thermalWait(context, cancelled, onPause)
                val tUs = i * 1_000_000L / fps

                val raw = getFrame(mmr, tUs, ow, oh)
                val frame: Bitmap = if (raw != null) {
                    fit(raw, ow, oh)
                } else {
                    val prev = lastRaw ?: throw IllegalStateException("cannot read video frames")
                    prev.copy(Bitmap.Config.ARGB_8888, true) ?: throw IllegalStateException("frame copy failed")
                }

                // Détecter les deux visages, puis associer chaque détection à sa piste.
                var detected = swapper.detectVideo(frame, angle, 0)
                angle = detected.second
                var candidates = detected.first
                // Les autres angles (13 détections) ne sont lancés que si le visage est perdu,
                // ou de temps en temps pour repérer une 2e personne qui entre dans le cadre.
                val doFull = (candidates.isEmpty() && (missRun < 3 || i % 4 == 0)) ||
                    (candidates.size in 1 until MAX_VIDEO_FACES && i % 20 == 0)
                if (doFull) {
                    val full = swapper.detectVideo(frame, angle, 1)
                    if (full.first.isNotEmpty()) {
                        val merged = ArrayList<FaceInfo>(candidates)
                        for (f in full.first) {
                            val duplicate = merged.any { old ->
                                val l = max(old.box.left, f.box.left)
                                val t = max(old.box.top, f.box.top)
                                val r = min(old.box.right, f.box.right)
                                val b = min(old.box.bottom, f.box.bottom)
                                val inter = max(0, r - l) * max(0, b - t)
                                val union = old.box.width() * old.box.height() + f.box.width() * f.box.height() - inter
                                union > 0 && inter.toFloat() / union > 0.25f
                            }
                            if (!duplicate) merged.add(f)
                        }
                        if (merged.size > candidates.size) angle = full.second
                        candidates = merged
                    }
                }

                if (candidates.isEmpty()) missRun++ else missRun = 0

                // Première image : choisir les deux plus grands visages, dans l'ordre gauche-droite.
                if (tracks.all { it == null } && candidates.isNotEmpty()) {
                    val initial = candidates.sortedByDescending { it.box.width() * it.box.height() }
                        .take(MAX_VIDEO_FACES).sortedBy { it.box.centerX() }
                    for (slot in initial.indices) {
                        tracks[slot] = FaceTrack(Rect(initial[slot].box), initial[slot].kps.copyOf())
                    }
                }

                val assigned = arrayOfNulls<FaceInfo>(MAX_VIDEO_FACES)
                val used = HashSet<Int>()
                // Libérer une piste absente durablement pour permettre une nouvelle entrée dans le cadre.
                for (slot in 0 until MAX_VIDEO_FACES) {
                    if ((tracks[slot]?.lost ?: 0) > 8) tracks[slot] = null
                }
                // Affectation globale par distance : évite qu'une piste prenne le visage de l'autre.
                data class PairDistance(val slot: Int, val candidate: Int, val distance: Float)
                val pairs = ArrayList<PairDistance>()
                for (slot in 0 until MAX_VIDEO_FACES) {
                    val track = tracks[slot] ?: continue
                    for (ci in candidates.indices) {
                        val c = candidates[ci]
                        val dx = c.box.exactCenterX() - track.box.exactCenterX()
                        val dy = c.box.exactCenterY() - track.box.exactCenterY()
                        val distance = sqrt(dx * dx + dy * dy)
                        val limit = 2.0f * max(track.box.width(), track.box.height()).toFloat()
                        if (distance <= limit) pairs.add(PairDistance(slot, ci, distance))
                    }
                }
                val usedSlots = HashSet<Int>()
                for (pair in pairs.sortedBy { it.distance }) {
                    if (pair.slot in usedSlots || pair.candidate in used) continue
                    assigned[pair.slot] = candidates[pair.candidate]
                    usedSlots.add(pair.slot)
                    used.add(pair.candidate)
                }
                // Si une piste n'existait pas encore, lui attribuer un visage non utilisé.
                for (slot in 0 until MAX_VIDEO_FACES) {
                    if (tracks[slot] == null) {
                        val ci = candidates.indices.firstOrNull { it !in used }
                        if (ci != null) {
                            used.add(ci)
                            val f = candidates[ci]
                            tracks[slot] = FaceTrack(Rect(f.box), f.kps.copyOf())
                            assigned[slot] = f
                        }
                    }
                }

                var out: Bitmap = frame
                var frameSwaps = 0
                for (slot in 0 until MAX_VIDEO_FACES) {
                    val track = tracks[slot] ?: continue
                    val found = assigned[slot]
                    if (found == null) {
                        track.lost++
                        noFace++
                        // Ne jamais appliquer une ancienne position : cela peut modifier l'arrière-plan.
                        continue
                    }
                    val kps = found.kps.copyOf()
                    var motion = 0f
                    for (k in 0 until 5) {
                        val dx = kps[2 * k] - track.kps[2 * k]
                        val dy = kps[2 * k + 1] - track.kps[2 * k + 1]
                        motion += sqrt(dx * dx + dy * dy)
                    }
                    motion /= 5f
                    val faceSize = max(1, max(found.box.width(), found.box.height())).toFloat()
                    val alpha = (motion / faceSize * 6f).coerceIn(0.35f, 1f)
                    for (k in 0 until 10) kps[k] = track.kps[k] + alpha * (kps[k] - track.kps[k])
                    track.box = Rect(found.box)
                    track.kps = kps.copyOf()
                    track.lost = 0
                    tracked++

                    try {
                        val face = FaceInfo(Rect(found.box), kps)
                        val swappedBitmap = swapper.swap(out, face, latent)
                        if (out !== frame) out.recycle()
                        out = swappedBitmap
                        if (opts.enhance && i % opts.enhanceEvery.coerceAtLeast(1) == 0) {
                            val enhanced = swapper.enhanceFace(out, face)
                            if (enhanced !== out) {
                                out.recycle()
                                out = enhanced
                            }
                        }
                        swapped++
                        frameSwaps++
                    } catch (e: Exception) {
                        noFace++
                    }
                }
                if (frameSwaps == 0 && tracks.all { it == null }) noFace++

                if (preview == null && out !== frame && i >= total / 3) {
                    val pv = Enhance.preview(out)
                    preview = if (pv === out) out.copy(Bitmap.Config.ARGB_8888, false) else pv
                }

                wr.addFrame(out, tUs)
                if (out !== frame) out.recycle()

                val old = lastRaw
                lastRaw = frame
                if (old != null && old !== frame) old.recycle()

                onProgress(i + 1, total)

                if (i == min(total - 1, 14) && swapped == 0) throw NoFaceException()
            }

            wr.finishVideo()
            if (audioIdx >= 0) {
                try { wr.copyAudio(context, videoUri, audioIdx, durUs) } catch (e: Exception) { }
            }
            wr.close()
            writer = null
            return VideoReport(total, swapped, tracked, noFace, preview, swapper.enhanceStatus, trimmed)
        } catch (e: Throwable) {
            writer?.abort()
            throw e
        } finally {
            try { lastRaw?.recycle() } catch (e: Exception) { }
            try { mmr.release() } catch (e: Exception) { }
        }
    }
}
