package com.klaws.face

import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private var targetUri: Uri? = null
    private var faceUri: Uri? = null
    private var targetIsVideo = false

    private lateinit var targetPreview: ImageView
    private lateinit var facePreview: ImageView
    private lateinit var targetLabel: TextView

    private val pickTarget = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            targetUri = uri
            val type = contentResolver.getType(uri) ?: ""
            targetIsVideo = type.startsWith("video")
            targetPreview.setImageURI(null)
            if (targetIsVideo) {
                targetPreview.setImageResource(R.drawable.ic_logo)
                targetLabel.text = getString(R.string.video_selected)
            } else {
                targetPreview.setImageURI(uri)
                targetLabel.text = getString(R.string.photo_selected)
            }
        }
    }

    private val pickFace = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            faceUri = uri
            facePreview.setImageURI(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        targetPreview = findViewById(R.id.targetPreview)
        facePreview = findViewById(R.id.facePreview)
        targetLabel = findViewById(R.id.targetLabel)

        findViewById<MaterialButton>(R.id.btnPickTarget).setOnClickListener {
            pickTarget.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
        }
        findViewById<MaterialButton>(R.id.btnPickFace).setOnClickListener {
            pickFace.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        findViewById<MaterialButton>(R.id.btnSwap).setOnClickListener {
            if (targetUri == null || faceUri == null) {
                Toast.makeText(this, R.string.pick_both, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, R.string.engine_soon, Toast.LENGTH_LONG).show()
            }
        }
    }
}
