package com.klaws.face

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.sqrt

class FaceInfo(val box: Rect, val kps: FloatArray)

class FaceSwapper(private val context: Context, private val modelsDir: File) {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setMinFaceSize(0.05f)
            .build()
    )

    private val arc = floatArrayOf(
        38.2946f, 51.6963f,
        73.5318f, 51.5014f,
        56.0252f, 71.7366f,
        41.5493f, 92.3655f,
        70.7299f, 92.2041f
    )

    fun close() {
        detector.close()
    }

    // ---------- Détection ----------
    fun detect(bmp: Bitmap): List<FaceInfo> {
        val faces = Tasks.await(detector.process(InputImage.fromBitmap(bmp, 0)))
        val list = ArrayList<FaceInfo>()
        for (f in faces) {
            val le = f.getLandmark(FaceLandmark.LEFT_EYE)?.position
            val re = f.getLandmark(FaceLandmark.RIGHT_EYE)?.position
            val nose = f.getLandmark(FaceLandmark.NOSE_BASE)?.position
            val ml = f.getLandmark(FaceLandmark.MOUTH_LEFT)?.position
            val mr = f.getLandmark(FaceLandmark.MOUTH_RIGHT)?.position
            if (le == null || re == null || nose == null || ml == null || mr == null) continue
            val eyes = listOf(le, re).sortedBy { it.x }
            val mouth = listOf(ml, mr).sortedBy { it.x }
            val kps = floatArrayOf(
                eyes[0].x, eyes[0].y,
                eyes[1].x, eyes[1].y,
                nose.x, nose.y,
                mouth[0].x, mouth[0].y,
                mouth[1].x, mouth[1].y
            )
            list.add(FaceInfo(f.boundingBox, kps))
        }
        return list.sortedByDescending { it.box.width() * it.box.height() }
    }

    // ---------- Alignement ----------
    private fun similarity(src: FloatArray, dst: FloatArray): Matrix {
        val n = 5
        var sx = 0f
        var sy = 0f
        var dx = 0f
        var dy = 0f
        for (i in 0 until n) {
            sx += src[2 * i]; sy += src[2 * i + 1]
            dx += dst[2 * i]; dy += dst[2 * i + 1]
        }
        sx /= n; sy /= n; dx /= n; dy /= n
        var num1 = 0f
        var num2 = 0f
        var den = 0f
        for (i in 0 until n) {
            val xs = src[2 * i] - sx
            val ys = src[2 * i + 1] - sy
            val xd = dst[2 * i] - dx
            val yd = dst[2 * i + 1] - dy
            num1 += xs * xd + ys * yd
            num2 += xs * yd - ys * xd
            den += xs * xs + ys * ys
        }
        val a = num1 / den
        val b = num2 / den
        val tx = dx - (a * sx - b * sy)
        val ty = dy - (b * sx + a * sy)
        val m = Matrix()
        m.setValues(floatArrayOf(a, -b, tx, b, a, ty, 0f, 0f, 1f))
        return m
    }

    private fun align(bmp: Bitmap, kps: FloatArray, size: Int, shiftX: Float): Pair<Bitmap, Matrix> {
        val dst = FloatArray(10)
        for (i in 0 until 10) {
            dst[i] = if (i % 2 == 0) arc[i] + shiftX else arc[i]
        }
        val m = similarity(kps, dst)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(bmp, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return Pair(out, m)
    }

    private fun toChw(bmp: Bitmap, mean: Float, std: Float): FloatArray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val out = FloatArray(3 * w * h)
        val plane = w * h
        for (i in px.indices) {
            val p = px[i]
            out[i] = (((p shr 16) and 255) - mean) / std
            out[plane + i] = (((p shr 8) and 255) - mean) / std
            out[2 * plane + i] = ((p and 255) - mean) / std
        }
        return out
    }

    private fun normalize(v: FloatArray): FloatArray {
        var s = 0f
        for (x in v) s += x * x
        val n = sqrt(s)
        val out = FloatArray(v.size)
        for (i in v.indices) out[i] = v[i] / n
        return out
    }

    private fun readFloats(t: OnnxTensor): FloatArray {
        val fb = t.floatBuffer
        val arr = FloatArray(fb.remaining())
        fb.get(arr)
        return arr
    }

    // ---------- Visage source -> vecteur ----------
    fun sourceLatent(src: Bitmap, face: FaceInfo): FloatArray {
        val (al, _) = align(src, face.kps, 112, 0f)
        val sess = env.createSession(File(modelsDir, Models.ARCFACE_FILE).absolutePath, OrtSession.SessionOptions())
        var emb = FloatArray(0)
        try {
            val name = sess.inputNames.iterator().next()
            val tensor = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(toChw(al, 127.5f, 127.5f)), longArrayOf(1, 3, 112, 112)
            )
            try {
                val res = sess.run(mapOf(name to tensor))
                try {
                    emb = normalize(readFloats(res[0] as OnnxTensor))
                } finally {
                    res.close()
                }
            } finally {
                tensor.close()
            }
        } finally {
            sess.close()
        }

        val bytes = context.assets.open("emap.bin").readBytes()
        val emap = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
        val emapArr = FloatArray(512 * 512)
        emap.get(emapArr)
        val lat = FloatArray(512)
        for (j in 0 until 512) {
            var s = 0f
            for (i in 0 until 512) s += emb[i] * emapArr[i * 512 + j]
            lat[j] = s
        }
        return normalize(lat)
    }

    // ---------- Changement du visage ----------
    fun swap(target: Bitmap, face: FaceInfo, latent: FloatArray): Bitmap {
        val (al, m) = align(target, face.kps, 128, 8f)
        val sess = env.createSession(File(modelsDir, Models.SWAPPER_FILE).absolutePath, OrtSession.SessionOptions())
        var outFloats = FloatArray(0)
        try {
            val names = sess.inputNames.toList()
            val tTarget = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(toChw(al, 0f, 255f)), longArrayOf(1, 3, 128, 128)
            )
            val tSource = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(latent), longArrayOf(1, 512)
            )
            try {
                val res = sess.run(mapOf(names[0] to tTarget, names[1] to tSource))
                try {
                    outFloats = readFloats(res[0] as OnnxTensor)
                } finally {
                    res.close()
                }
            } finally {
                tTarget.close()
                tSource.close()
            }
        } finally {
            sess.close()
        }

        // Image 128x128 avec masque doux (ellipse)
        val size = 128
        val plane = size * size
        val px = IntArray(plane)
        for (y in 0 until size) {
            for (x in 0 until size) {
                val i = y * size + x
                val r = (outFloats[i] * 255f).coerceIn(0f, 255f).toInt()
                val g = (outFloats[plane + i] * 255f).coerceIn(0f, 255f).toInt()
                val b = (outFloats[2 * plane + i] * 255f).coerceIn(0f, 255f).toInt()
                val dx = (x - 64f) / 44f
                val dy = (y - 70f) / 54f
                val d = sqrt(dx * dx + dy * dy)
                val alpha = ((1f - d) / 0.25f).coerceIn(0f, 1f)
                val a = (alpha * 255f).toInt()
                px[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val fake = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        fake.setPixels(px, 0, size, 0, 0, size, size)

        val inv = Matrix()
        m.invert(inv)
        val result = target.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(result)
        c.drawBitmap(fake, inv, Paint(Paint.FILTER_BITMAP_FLAG))
        return result
    }
}
