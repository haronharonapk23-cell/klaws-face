package com.klaws.face

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.io.File
import kotlin.math.max

class MainActivity : AppCompatActivity() {

    private var targetUri: Uri? = null
    private var faceUri: Uri? = null

    private lateinit var targetPreview: ImageView
    private lateinit var facePreview: ImageView
    private lateinit var resultPreview: ImageView
    private lateinit var hintTarget: View
    private lateinit var hintFace: View
    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnSwap: MaterialButton

    private val pickTarget = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            targetUri = uri
            targetPreview.setImageURI(null)
            targetPreview.setImageURI(uri)
            hintTarget.visibility = View.GONE
        }
    }

    private val pickFace = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            faceUri = uri
            facePreview.setImageURI(null)
            facePreview.setImageURI(uri)
            hintFace.visibility = View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        targetPreview = findViewById(R.id.targetPreview)
        facePreview = findViewById(R.id.facePreview)
        resultPreview = findViewById(R.id.resultPreview)
        hintTarget = findViewById(R.id.hintTarget)
        hintFace = findViewById(R.id.hintFace)
        statusText = findViewById(R.id.statusText)
        progress = findViewById(R.id.progress)
        btnSwap = findViewById(R.id.btnSwap)

        findViewById<View>(R.id.boxTarget).setOnClickListener {
            pickTarget.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        findViewById<View>(R.id.boxFace).setOnClickListener {
            pickFace.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        btnSwap.setOnClickListener { startSwap() }

        val soon = View.OnClickListener {
            Toast.makeText(this, R.string.soon, Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.modeVideo).setOnClickListener(soon)
        findViewById<View>(R.id.tabMulti).setOnClickListener(soon)
        findViewById<View>(R.id.tabBatch).setOnClickListener(soon)
    }

    private fun setStatus(text: String, percent: Int = -1) {
        runOnUiThread {
            statusText.text = text
            if (percent >= 0) {
                progress.visibility = View.VISIBLE
                progress.progress = percent
            } else {
                progress.visibility = View.GONE
            }
        }
    }

    private fun startSwap() {
        val t = targetUri
        val f = faceUri
        if (t == null || f == null) {
            Toast.makeText(this, R.string.pick_both, Toast.LENGTH_SHORT).show()
            return
        }
        btnSwap.isEnabled = false
        resultPreview.setImageDrawable(null)

        Thread {
            var swapper: FaceSwapper? = null
            try {
                val dir = File(filesDir, "models")

                Downloader.ensure(dir, Models.ARCFACE_FILE, Models.ARCFACE_URLS, Models.ARCFACE_MIN) { p ->
                    setStatus(getString(R.string.downloading_models, 1, p), p)
                }
                Downloader.ensure(dir, Models.SWAPPER_FILE, Models.SWAPPER_URLS, Models.SWAPPER_MIN) { p ->
                    setStatus(getString(R.string.downloading_models, 2, p), p)
                }

                setStatus(getString(R.string.detecting))
                val targetBmp = loadBitmap(t)
                val sourceBmp = loadBitmap(f)
                swapper = FaceSwapper(applicationContext, dir)

                val targetFaces = swapper.detect(targetBmp)
                if (targetFaces.isEmpty()) {
                    setStatus(getString(R.string.no_face_target))
                    return@Thread
                }
                val sourceFaces = swapper.detect(sourceBmp)
                if (sourceFaces.isEmpty()) {
                    setStatus(getString(R.string.no_face_source))
                    return@Thread
                }

                setStatus(getString(R.string.swapping))
                val latent = swapper.sourceLatent(sourceBmp, sourceFaces[0])
                val result = swapper.swap(targetBmp, targetFaces[0], latent)

                val where = saveToGallery(result)
                runOnUiThread { resultPreview.setImageBitmap(result) }
                setStatus(getString(R.string.done, where))
            } catch (e: Throwable) {
                setStatus(getString(R.string.error_generic, e.toString()))
            } finally {
                swapper?.close()
                runOnUiThread { btnSwap.isEnabled = true }
            }
        }.start()
    }

    private fun loadBitmap(uri: Uri, maxSide: Int = 2048): Bitmap {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        val bmp = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalStateException("decode failed")

        var degrees = 0f
        try {
            contentResolver.openInputStream(uri).use { s ->
                if (s != null) {
                    val exif = ExifInterface(s)
                    degrees = when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                }
            }
        } catch (e: Exception) {
            degrees = 0f
        }
        if (degrees != 0f) {
            val m = Matrix()
            m.postRotate(degrees)
            return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        return bmp
    }

    private fun saveToGallery(bmp: Bitmap): String {
        val name = "KlawsFace_" + System.currentTimeMillis() + ".jpg"
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues()
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name)
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/KlawsFace")
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("save failed")
            contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            return "Pictures/KlawsFace/$name"
        } else {
            val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
            val file = File(dir, name)
            file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            return file.path
        }
    }
}
