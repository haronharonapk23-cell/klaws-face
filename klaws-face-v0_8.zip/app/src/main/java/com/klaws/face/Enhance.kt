package com.klaws.face

import android.graphics.Bitmap
import kotlin.math.max

/** Agrandissement jusqu'à 4K + accentuation de la netteté. */
object Enhance {

    /** Taille max de chargement : une photo 12 Mpx (4032 px) reste à sa résolution réelle. */
    const val TARGET_SIDE = 4608

    fun to4k(src: Bitmap): Bitmap {
        val m = max(src.width, src.height)
        if (m >= TARGET_SIDE) return src
        val s = TARGET_SIDE.toFloat() / m
        return Bitmap.createScaledBitmap(
            src, (src.width * s).toInt().coerceAtLeast(1), (src.height * s).toInt().coerceAtLeast(1), true
        )
    }

    /** Masque flou (unsharp mask), traité par bandes pour économiser la mémoire. */
    fun sharpen(src: Bitmap, amount: Float = 0.55f): Bitmap {
        val w = src.width
        val h = src.height
        val small = Bitmap.createScaledBitmap(src, max(1, w / 3), max(1, h / 3), true)
        val blur = Bitmap.createScaledBitmap(small, w, h, true)
        if (small !== src) small.recycle()
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val band = 128
        val a = IntArray(w * band)
        val b = IntArray(w * band)
        var y = 0
        while (y < h) {
            val rows = minOf(band, h - y)
            src.getPixels(a, 0, w, 0, y, w, rows)
            blur.getPixels(b, 0, w, 0, y, w, rows)
            for (i in 0 until w * rows) {
                val p = a[i]
                val q = b[i]
                val r = ((p shr 16) and 255)
                val g = ((p shr 8) and 255)
                val bl = (p and 255)
                val nr = (r + amount * (r - ((q shr 16) and 255))).toInt().coerceIn(0, 255)
                val ng = (g + amount * (g - ((q shr 8) and 255))).toInt().coerceIn(0, 255)
                val nb = (bl + amount * (bl - (q and 255))).toInt().coerceIn(0, 255)
                a[i] = (255 shl 24) or (nr shl 16) or (ng shl 8) or nb
            }
            out.setPixels(a, 0, w, 0, y, w, rows)
            y += rows
        }
        blur.recycle()
        return out
    }

    /**
     * Netteté légère SANS agrandissement artificiel : étirer une image avec un filtre bilinéaire
     * la rend floue (cause de la qualité faible des versions précédentes).
     * En cas de manque de mémoire, retourne l'image d'origine.
     */
    fun finish(src: Bitmap): Bitmap {
        return try {
            sharpen(src, 0.35f)
        } catch (e: OutOfMemoryError) {
            src
        }
    }

    /** Petite image pour l'aperçu à l'écran. */
    fun preview(src: Bitmap, maxSide: Int = 1600): Bitmap {
        val m = max(src.width, src.height)
        if (m <= maxSide) return src
        val s = maxSide.toFloat() / m
        return Bitmap.createScaledBitmap(src, (src.width * s).toInt(), (src.height * s).toInt(), true)
    }
}
