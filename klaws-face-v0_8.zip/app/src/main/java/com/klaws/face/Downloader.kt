package com.klaws.face

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object Models {
    val SWAPPER_URLS = listOf(
        "https://huggingface.co/ezioruan/inswapper_128.onnx/resolve/main/inswapper_128.onnx",
        "https://huggingface.co/countfloyd/deepfake/resolve/main/inswapper_128.onnx"
    )
    val ARCFACE_URLS = listOf(
        "https://huggingface.co/globalnebula/insightface-buffalo-l-onnx/resolve/main/arcface_w600k_r50.onnx",
        "https://huggingface.co/karanjakhar/insightface_weights/resolve/main/w600k_r50.onnx"
    )
    // Amélioration du visage (GFPGAN 1.4) : optionnel, si le téléchargement échoue le swap marche quand même
    val GFPGAN_URLS = listOf(
        "https://huggingface.co/datasets/Gourieff/ReActor/resolve/main/models/facerestore_models/GFPGANv1.4.onnx",
        "https://github.com/facefusion/facefusion-assets/releases/download/models/gfpgan_1.4.onnx",
        "https://huggingface.co/Neus/GFPGANv1.4/resolve/main/GFPGANv1.4.onnx"
    )
    const val GFPGAN_FILE = "GFPGANv1.4.onnx"
    const val GFPGAN_MIN = 250_000_000L
    const val SWAPPER_FILE = "inswapper_128.onnx"
    const val ARCFACE_FILE = "w600k_r50.onnx"
    const val SWAPPER_MIN = 500_000_000L
    const val ARCFACE_MIN = 100_000_000L
}

object Downloader {

    fun ensure(dir: File, name: String, urls: List<String>, minSize: Long, onProgress: (Int) -> Unit): File {
        val out = File(dir, name)
        if (out.exists() && out.length() >= minSize) return out
        dir.mkdirs()
        var lastError: Exception? = null
        for (u in urls) {
            try {
                val tmp = File(dir, "$name.part")
                if (tmp.exists()) tmp.delete()
                download(u, tmp, onProgress)
                if (tmp.length() < minSize) throw IOException("incomplete file")
                if (out.exists()) out.delete()
                if (!tmp.renameTo(out)) throw IOException("rename failed")
                return out
            } catch (e: Exception) {
                lastError = e
            }
        }
        throw lastError ?: IOException("download failed")
    }

    private fun download(url: String, dest: File, onProgress: (Int) -> Unit) {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "KlawsFace/0.2")
        if (conn.responseCode !in 200..299) throw IOException("HTTP " + conn.responseCode)
        val total = conn.contentLengthLong
        val input = conn.inputStream
        val output = FileOutputStream(dest)
        try {
            val buf = ByteArray(64 * 1024)
            var done = 0L
            var last = -1
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                output.write(buf, 0, n)
                done += n
                if (total > 0) {
                    val p = (done * 100 / total).toInt()
                    if (p != last) {
                        last = p
                        onProgress(p)
                    }
                }
            }
        } finally {
            output.close()
            input.close()
            conn.disconnect()
        }
    }
}
