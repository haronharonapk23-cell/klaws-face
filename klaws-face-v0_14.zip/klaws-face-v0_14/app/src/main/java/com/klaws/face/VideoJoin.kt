package com.klaws.face

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.io.FileDescriptor
import java.nio.ByteBuffer
import kotlin.math.max

/** Assemble les segments MP4 (sans recompression) et recopie le son d'origine. */
object VideoJoin {

    private fun videoTrackOf(ex: MediaExtractor): Int {
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("video/")) return i
        }
        return -1
    }

    fun join(
        context: Context,
        segFiles: List<File>,
        segStartFrames: List<Int>,
        fps: Int,
        audioSource: Uri,
        audioIdx: Int,
        durUs: Long,
        outFd: FileDescriptor,
        cancelled: () -> Boolean
    ) {
        val muxer = MediaMuxer(outFd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var audioEx: MediaExtractor? = null
        try {
            val ex0 = MediaExtractor()
            val vFmt: MediaFormat = try {
                ex0.setDataSource(segFiles[0].path)
                val vi0 = videoTrackOf(ex0)
                if (vi0 < 0) throw IllegalStateException("no video track")
                ex0.getTrackFormat(vi0)
            } finally {
                ex0.release()
            }
            val vTrack = muxer.addTrack(vFmt)

            var aTrack = -1
            if (audioIdx >= 0) {
                try {
                    val ae = MediaExtractor()
                    audioEx = ae
                    ae.setDataSource(context, audioSource, null)
                    aTrack = muxer.addTrack(ae.getTrackFormat(audioIdx))
                } catch (e: Exception) {
                    aTrack = -1
                    try { audioEx?.release() } catch (e2: Exception) { }
                    audioEx = null
                }
            }
            muxer.start()

            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val bi = MediaCodec.BufferInfo()
            for (k in segFiles.indices) {
                if (cancelled()) throw CancelledException()
                val offUs = segStartFrames[k] * 1_000_000L / fps
                val ex = MediaExtractor()
                try {
                    ex.setDataSource(segFiles[k].path)
                    val vi = videoTrackOf(ex)
                    if (vi < 0) throw IllegalStateException("no video track in segment")
                    ex.selectTrack(vi)
                    while (true) {
                        buf.clear()
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) break
                        val flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                        bi.set(0, size, ex.sampleTime + offUs, flags)
                        muxer.writeSampleData(vTrack, buf, bi)
                        ex.advance()
                    }
                } finally {
                    ex.release()
                }
            }

            val ae = audioEx
            if (ae != null && aTrack >= 0) {
                try {
                    ae.selectTrack(audioIdx)
                    ae.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                    var cap = 262144
                    val f = ae.getTrackFormat(audioIdx)
                    if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        cap = max(cap, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
                    }
                    val abuf = ByteBuffer.allocate(cap)
                    while (true) {
                        abuf.clear()
                        val size = ae.readSampleData(abuf, 0)
                        if (size < 0) break
                        val t = ae.sampleTime
                        if (t < 0 || t > durUs) break
                        val flags = if ((ae.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                        bi.set(0, size, t, flags)
                        muxer.writeSampleData(aTrack, abuf, bi)
                        ae.advance()
                    }
                } catch (e: Exception) {
                    // le son est facultatif : la vidéo reste valide sans lui
                }
            }
            muxer.stop()
        } finally {
            try { audioEx?.release() } catch (e: Exception) { }
            try { muxer.release() } catch (e: Exception) { }
        }
    }
}
