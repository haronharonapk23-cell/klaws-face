package com.klaws.face

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import java.io.FileDescriptor
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** maxSide : plus grand côté de la vidéo de sortie (1920 = 1080p). maxFps : images/seconde maximum. */
class VideoOptions(val maxSide: Int, val maxFps: Int, val enhance: Boolean)

class VideoReport(
    val total: Int,
    val swapped: Int,
    val tracked: Int,
    val noFace: Int,
    val preview: Bitmap?,
    val enhanceStatus: String,
    val trimmed: Boolean
)

class CancelledException : RuntimeException("cancelled")
class NoFaceException : RuntimeException("no face in video")

/** Écrit une vidéo MP4 (H.264) image par image, puis recopie le son d'origine sans le recompresser. */
class Mp4Writer(
    fd: FileDescriptor,
    private val w: Int,
    private val h: Int,
    fps: Int,
    private val audioFmt: MediaFormat?
) {
    private val muxer = MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val enc: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
    private val info = MediaCodec.BufferInfo()
    private val argb = IntArray(w * h)
    private var vTrack = -1
    var aTrack = -1
        private set
    private var started = false
    private var lastPts = 0L

    init {
        val bitrate = (w.toLong() * h * fps * 0.14).toLong().coerceIn(3_000_000L, 30_000_000L).toInt()
        val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
        f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        f.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
        f.setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
        enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
    }

    /** bmp doit avoir exactement la taille w x h. */
    fun addFrame(bmp: Bitmap, ptsUs: Long) {
        bmp.getPixels(argb, 0, w, 0, 0, w, h)
        var idx: Int
        while (true) {
            idx = enc.dequeueInputBuffer(10_000)
            if (idx >= 0) break
            drain(false)
        }
        val img = enc.getInputImage(idx) ?: throw IllegalStateException("encoder input image unavailable")
        fill(img)
        enc.queueInputBuffer(idx, 0, w * h * 3 / 2, ptsUs, 0)
        lastPts = ptsUs
        drain(false)
    }

    private fun fill(img: Image) {
        val yP = img.planes[0]
        val uP = img.planes[1]
        val vP = img.planes[2]
        val yB = yP.buffer
        val uB = uP.buffer
        val vB = vP.buffer
        val yRow = yP.rowStride
        val uRow = uP.rowStride
        val vRow = vP.rowStride
        val uPix = uP.pixelStride
        val vPix = vP.pixelStride
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val p00 = argb[y * w + x]
                val p01 = argb[y * w + x + 1]
                val p10 = argb[(y + 1) * w + x]
                val p11 = argb[(y + 1) * w + x + 1]
                var rs = 0
                var gs = 0
                var bs = 0
                for (k in 0 until 4) {
                    val p = when (k) { 0 -> p00; 1 -> p01; 2 -> p10; else -> p11 }
                    val r = (p shr 16) and 255
                    val g = (p shr 8) and 255
                    val b = p and 255
                    rs += r; gs += g; bs += b
                    val yy = ((47 * r + 157 * g + 16 * b + 128) shr 8) + 16
                    val dx = k and 1
                    val dy = k shr 1
                    yB.put((y + dy) * yRow + x + dx, yy.coerceIn(16, 235).toByte())
                }
                val r = rs shr 2
                val g = gs shr 2
                val b = bs shr 2
                val u = ((-26 * r - 87 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 102 * g - 10 * b + 128) shr 8) + 128
                uB.put((y / 2) * uRow + (x / 2) * uPix, u.coerceIn(16, 240).toByte())
                vB.put((y / 2) * vRow + (x / 2) * vPix, v.coerceIn(16, 240).toByte())
                x += 2
            }
            y += 2
        }
    }

    private fun drain(eos: Boolean) {
        var idle = 0
        while (true) {
            val oi = enc.dequeueOutputBuffer(info, if (eos) 10_000L else 0L)
            if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!eos) return
                idle++
                if (idle > 1000) throw IllegalStateException("encoder timeout")
                continue
            }
            if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                vTrack = muxer.addTrack(enc.outputFormat)
                val af = audioFmt
                if (af != null) {
                    aTrack = try { muxer.addTrack(af) } catch (e: Exception) { -1 }
                }
                muxer.start()
                started = true
                continue
            }
            if (oi < 0) continue
            idle = 0
            val buf = enc.getOutputBuffer(oi)
            if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
            if (info.size > 0 && buf != null && started) {
                buf.position(info.offset)
                buf.limit(info.offset + info.size)
                muxer.writeSampleData(vTrack, buf, info)
            }
            enc.releaseOutputBuffer(oi, false)
            if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
        }
    }

    fun finishVideo() {
        var idx: Int
        while (true) {
            idx = enc.dequeueInputBuffer(10_000)
            if (idx >= 0) break
            drain(false)
        }
        enc.queueInputBuffer(idx, 0, 0, lastPts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        drain(true)
    }

    /** Recopie la piste audio telle quelle (sans recompression), limitée à la durée traitée. */
    fun copyAudio(context: Context, uri: Uri, audioIndex: Int, maxUs: Long) {
        if (aTrack < 0 || !started) return
        val ex = MediaExtractor()
        try {
            ex.setDataSource(context, uri, null)
            ex.selectTrack(audioIndex)
            ex.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            var cap = 262144
            val f = ex.getTrackFormat(audioIndex)
            if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                cap = max(cap, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
            }
            val buf = ByteBuffer.allocate(cap)
            val bi = MediaCodec.BufferInfo()
            while (true) {
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (t < 0 || t > maxUs) break
                val flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                bi.set(0, size, t, flags)
                muxer.writeSampleData(aTrack, buf, bi)
                ex.advance()
            }
        } finally {
            ex.release()
        }
    }

    fun close() {
        try { enc.stop() } catch (e: Exception) { }
        try { enc.release() } catch (e: Exception) { }
        try { muxer.stop() } catch (e: Exception) { }
        try { muxer.release() } catch (e: Exception) { }
    }

    fun abort() {
        try { enc.stop() } catch (e: Exception) { }
        try { enc.release() } catch (e: Exception) { }
        try { muxer.release() } catch (e: Exception) { }
    }
}

object VideoSwapper {

    const val MAX_SECONDS = 90

    private fun getFrame(r: MediaMetadataRetriever, tUs: Long): Bitmap? {
        var b: Bitmap? = null
        try { b = r.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST) } catch (e: Exception) { }
        if (b == null) {
            try { b = r.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) } catch (e: Exception) { }
        }
        return b
    }

    private fun fit(src: Bitmap, ow: Int, oh: Int): Bitmap {
        var b = src
        if (b.config == Bitmap.Config.HARDWARE) {
            val c = b.copy(Bitmap.Config.ARGB_8888, true)
            b.recycle()
            b = c ?: throw IllegalStateException("frame copy failed")
        }
        if (b.width == ow && b.height == oh) return b
        val s = Bitmap.createScaledBitmap(b, ow, oh, true)
        if (s !== b) b.recycle()
        return s
    }

    private fun pickFace(cands: List<FaceInfo>, lastBox: Rect?): FaceInfo? {
        if (cands.isEmpty()) return null
        if (lastBox == null) return cands[0]
        val lx = lastBox.exactCenterX()
        val ly = lastBox.exactCenterY()
        var best: FaceInfo? = null
        var bestD = Float.MAX_VALUE
        for (c in cands) {
            val dx = c.box.exactCenterX() - lx
            val dy = c.box.exactCenterY() - ly
            val d = sqrt(dx * dx + dy * dy)
            if (d < bestD) { bestD = d; best = c }
        }
        val limit = 1.6f * max(lastBox.width(), lastBox.height()).toFloat()
        return if (bestD <= limit) best else null
    }

    private fun frameRateOf(f: MediaFormat): Int {
        return try {
            f.getInteger(MediaFormat.KEY_FRAME_RATE)
        } catch (e: Exception) {
            try { f.getFloat(MediaFormat.KEY_FRAME_RATE).toInt() } catch (e2: Exception) { 30 }
        }
    }

    fun process(
        context: Context,
        swapper: FaceSwapper,
        videoUri: Uri,
        latent: FloatArray,
        opts: VideoOptions,
        outFd: FileDescriptor,
        onProgress: (Int, Int) -> Unit,
        cancelled: () -> Boolean
    ): VideoReport {
        val mmr = MediaMetadataRetriever()
        mmr.setDataSource(context, videoUri)
        var writer: Mp4Writer? = null
        var lastRaw: Bitmap? = null
        try {
            val durMs = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            if (durMs <= 0L) throw IllegalStateException("video duration unknown")

            // fps source + piste audio
            var srcFps = 30
            var audioIdx = -1
            var audioFmt: MediaFormat? = null
            val ex = MediaExtractor()
            try {
                ex.setDataSource(context, videoUri, null)
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("video/") && f.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        srcFps = frameRateOf(f)
                    }
                    if (mime.startsWith("audio/") && audioIdx < 0) {
                        audioIdx = i
                        audioFmt = f
                    }
                }
            } catch (e: Exception) {
            } finally {
                ex.release()
            }

            val fps = min(srcFps.coerceIn(5, 60), opts.maxFps)
            val durUs = min(durMs, MAX_SECONDS * 1000L) * 1000L
            val trimmed = durMs > MAX_SECONDS * 1000L + 500L
            val total = (durUs * fps / 1_000_000L).toInt().coerceAtLeast(1)

            val first = getFrame(mmr, 0L) ?: throw IllegalStateException("cannot read video frames")
            val sc = min(1f, opts.maxSide.toFloat() / max(first.width, first.height))
            val ow = max(16, ((first.width * sc).toInt() / 16) * 16)
            val oh = max(16, ((first.height * sc).toInt() / 16) * 16)
            first.recycle()

            val wr = Mp4Writer(outFd, ow, oh, fps, audioFmt)
            writer = wr

            var angle = 0
            var lastKps: FloatArray? = null
            var lastBox: Rect? = null
            var lost = 0
            var swapped = 0
            var tracked = 0
            var noFace = 0
            var preview: Bitmap? = null

            for (i in 0 until total) {
                if (cancelled()) throw CancelledException()
                val tUs = i * 1_000_000L / fps

                val raw = getFrame(mmr, tUs)
                val frame: Bitmap = if (raw != null) {
                    fit(raw, ow, oh)
                } else {
                    val prev = lastRaw ?: throw IllegalStateException("cannot read video frames")
                    prev.copy(Bitmap.Config.ARGB_8888, true) ?: throw IllegalStateException("frame copy failed")
                }

                // ----- détection + suivi -----
                var pick: FaceInfo? = null
                var foundAngle = angle
                run {
                    val q = swapper.detectVideo(frame, angle, 0)
                    pick = pickFace(q.first, lastBox)
                    foundAngle = q.second
                    if (pick == null) {
                        val full = swapper.detectVideo(frame, angle, 1)
                        pick = pickFace(full.first, lastBox)
                        foundAngle = full.second
                    }
                }

                var face: FaceInfo? = null
                var counted = false
                val p = pick
                if (p != null) {
                    angle = foundAngle
                    val kps = p.kps.copyOf()
                    val prevK = lastKps
                    if (prevK != null) {
                        // lissage anti-scintillement : fort quand le visage bouge peu, nul quand il bouge vite
                        var d = 0f
                        for (k in 0 until 5) {
                            val dx = kps[2 * k] - prevK[2 * k]
                            val dy = kps[2 * k + 1] - prevK[2 * k + 1]
                            d += sqrt(dx * dx + dy * dy)
                        }
                        d /= 5f
                        val size = max(1, max(p.box.width(), p.box.height())).toFloat()
                        val a = (d / size * 6f).coerceIn(0.35f, 1f)
                        for (k in 0 until 10) kps[k] = prevK[k] + a * (kps[k] - prevK[k])
                    }
                    lastKps = kps
                    lastBox = Rect(p.box)
                    lost = 0
                    face = FaceInfo(Rect(p.box), kps)
                    swapped++
                    counted = true
                } else {
                    val lk = lastKps
                    val lb = lastBox
                    if (lk != null && lb != null && lost < 12) {
                        // visage perdu quelques images (acrobatie, flou) : on garde la dernière position
                        lost++
                        face = FaceInfo(Rect(lb), lk.copyOf())
                        tracked++
                        counted = true
                    } else {
                        lost++
                        noFace++
                    }
                }

                // ----- échange du visage -----
                var out: Bitmap = frame
                if (face != null) {
                    try {
                        val sw = swapper.swap(frame, face, latent)
                        val en = if (opts.enhance) swapper.enhanceFace(sw, face) else sw
                        if (en !== sw) sw.recycle()
                        out = en
                    } catch (e: Exception) {
                        out = frame
                        if (counted) {
                            // l'échec ne compte pas comme un visage remplacé
                            if (p != null) swapped-- else tracked--
                            noFace++
                        }
                    }
                }

                if (preview == null && out !== frame && i >= total / 3) {
                    val pv = Enhance.preview(out)
                    preview = if (pv === out) out.copy(Bitmap.Config.ARGB_8888, false) else pv
                }

                wr.addFrame(out, tUs)
                if (out !== frame) out.recycle()

                val old = lastRaw
                lastRaw = frame
                if (old != null && old !== frame) old.recycle()

                onProgress(i + 1, total)

                if (i == min(total - 1, 14) && swapped == 0 && tracked == 0) throw NoFaceException()
            }

            wr.finishVideo()
            if (audioIdx >= 0) {
                try { wr.copyAudio(context, videoUri, audioIdx, durUs) } catch (e: Exception) { }
            }
            wr.close()
            writer = null
            return VideoReport(total, swapped, tracked, noFace, preview, swapper.enhanceStatus, trimmed)
        } catch (e: Throwable) {
            writer?.abort()
            throw e
        } finally {
            try { lastRaw?.recycle() } catch (e: Exception) { }
            try { mmr.release() } catch (e: Exception) { }
        }
    }
}
