package com.klaws.face

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import android.graphics.Color
import android.graphics.Outline
import android.view.Gravity
import android.view.ViewOutlineProvider
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.io.File
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private var targetUri: Uri? = null
    private var faceUri: Uri? = null

    private lateinit var targetPreview: ImageView
    private lateinit var facePreview: ImageView
    private lateinit var resultPreview: ImageView
    private lateinit var hintTarget: View
    private lateinit var hintFace: View
    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnSwap: MaterialButton
    private lateinit var progressText: TextView
    private lateinit var chkRights: CheckBox
    private lateinit var faceBoxes: FaceBoxesView
    private lateinit var facesInfo: TextView
    private lateinit var multiRows: LinearLayout
    private lateinit var faceTitle: View
    private lateinit var faceSub: View
    private lateinit var boxFace: View
    private lateinit var tabSingle: TextView
    private lateinit var tabMulti: TextView
    private lateinit var scroll: ScrollView
    private lateinit var btnDownload: MaterialButton
    private var lastSavedUri: Uri? = null
    private var lastSavedPath: String = ""

    // ----- mode « Plusieurs visages » -----
    private var multiMode = false
    private var multiTargetBmp: Bitmap? = null
    private var multiFaces: List<FaceInfo> = emptyList()
    private val multiUris = ArrayList<Uri?>()
    private val multiThumbs = ArrayList<ImageView>()
    private var pendingIndex = -1
    private var detector: FaceSwapper? = null

    // ----- progression + compteur de secondes -----
    private val ui = Handler(Looper.getMainLooper())
    private var tickRunning = false
    private var startMs = 0L
    @Volatile private var shown = 0f
    @Volatile private var stageCap = 0f
    private val ticker = object : Runnable {
        override fun run() {
            if (!tickRunning) return
            shown += (stageCap - shown) * 0.08f
            renderProgress()
            ui.postDelayed(this, 200)
        }
    }

    private val pickTarget = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            targetUri = uri
            hintTarget.visibility = View.GONE
            if (multiMode) {
                detectForMulti(uri)
            } else {
                targetPreview.setImageURI(null)
                targetPreview.setImageURI(uri)
            }
        }
    }

    private val pickMultiFace = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        val i = pendingIndex
        if (uri != null && i >= 0 && i < multiUris.size) {
            multiUris[i] = uri
            multiThumbs[i].setImageURI(null)
            multiThumbs[i].setImageURI(uri)
            multiThumbs[i].setPadding(0, 0, 0, 0)
            multiThumbs[i].setBackgroundColor(Color.TRANSPARENT)
        }
        pendingIndex = -1
    }

    private val pickFace = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            faceUri = uri
            facePreview.setImageURI(null)
            facePreview.setImageURI(uri)
            hintFace.visibility = View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        targetPreview = findViewById(R.id.targetPreview)
        facePreview = findViewById(R.id.facePreview)
        resultPreview = findViewById(R.id.resultPreview)
        hintTarget = findViewById(R.id.hintTarget)
        hintFace = findViewById(R.id.hintFace)
        statusText = findViewById(R.id.statusText)
        progress = findViewById(R.id.progress)
        btnSwap = findViewById(R.id.btnSwap)
        progressText = findViewById(R.id.progressText)
        chkRights = findViewById(R.id.chkRights)
        faceBoxes = findViewById(R.id.faceBoxes)
        facesInfo = findViewById(R.id.facesInfo)
        multiRows = findViewById(R.id.multiRows)
        faceTitle = findViewById(R.id.faceTitle)
        faceSub = findViewById(R.id.faceSub)
        boxFace = findViewById(R.id.boxFace)
        tabSingle = findViewById(R.id.tabSingle)
        tabMulti = findViewById(R.id.tabMulti)
        scroll = findViewById(R.id.scroll)
        btnDownload = findViewById(R.id.btnDownload)
        resultPreview.maxHeight = (resources.displayMetrics.heightPixels * 0.55f).toInt()

        findViewById<View>(R.id.boxTarget).setOnClickListener {
            pickTarget.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        findViewById<View>(R.id.boxFace).setOnClickListener {
            pickFace.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        btnSwap.setOnClickListener { startSwap() }
        btnDownload.setOnClickListener { openSaved() }

        val soon = View.OnClickListener {
            Toast.makeText(this, R.string.soon, Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.modeVideo).setOnClickListener(soon)
        tabSingle.setOnClickListener { setMultiMode(false) }
        tabMulti.setOnClickListener { setMultiMode(true) }
        findViewById<View>(R.id.tabBatch).setOnClickListener(soon)
    }

    private fun setStatus(text: String, percent: Int = -1) {
        runOnUiThread {
            statusText.text = text
            if (percent >= 0) {
                progress.visibility = View.VISIBLE
                progress.progress = percent
            } else if (!tickRunning && progressText.visibility != View.VISIBLE) {
                progress.visibility = View.GONE
            }
        }
    }

    // ---------- progression en % + secondes ----------
    private fun renderProgress() {
        val secs = ((SystemClock.elapsedRealtime() - startMs) / 1000).toInt()
        val p = shown.toInt().coerceIn(0, 100)
        progress.progress = p
        progressText.text = getString(R.string.progress_fmt, p, secs)
    }

    private fun beginProgress() {
        runOnUiThread {
            startMs = SystemClock.elapsedRealtime()
            shown = 0f
            stageCap = 0f
            progress.visibility = View.VISIBLE
            progressText.visibility = View.VISIBLE
            tickRunning = true
            renderProgress()
            ui.post(ticker)
        }
    }

    /** Fixe le palier : la barre est au moins à [from] % et avance doucement vers [to] % pendant l'étape. */
    private fun stage(from: Int, to: Int, label: String) {
        runOnUiThread {
            if (shown < from) shown = from.toFloat()
            stageCap = (to - 1).toFloat()
            statusText.text = label
            renderProgress()
        }
    }

    private fun endProgress(ok: Boolean) {
        runOnUiThread {
            tickRunning = false
            ui.removeCallbacks(ticker)
            if (ok) shown = 100f
            renderProgress()
        }
    }

    // ---------- Un visage / Plusieurs visages ----------
    private fun setMultiMode(on: Boolean) {
        multiMode = on
        tabSingle.setBackgroundResource(if (on) 0 else R.drawable.tab_on)
        tabMulti.setBackgroundResource(if (on) R.drawable.tab_on else 0)
        tabSingle.setTextColor(resources.getColor(if (on) R.color.gray else R.color.accent, theme))
        tabMulti.setTextColor(resources.getColor(if (on) R.color.accent else R.color.gray, theme))
        tabSingle.setTypeface(null, if (on) android.graphics.Typeface.NORMAL else android.graphics.Typeface.BOLD)
        tabMulti.setTypeface(null, if (on) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        val vis = if (on) View.GONE else View.VISIBLE
        faceTitle.visibility = vis
        faceSub.visibility = vis
        boxFace.visibility = vis
        resultPreview.setImageDrawable(null)
        val t = targetUri
        if (on) {
            if (t != null) detectForMulti(t) else statusText.text = getString(R.string.tap_to_detect)
        } else {
            faceBoxes.visibility = View.GONE
            facesInfo.visibility = View.GONE
            multiRows.visibility = View.GONE
            if (t != null) {
                targetPreview.setImageURI(null)
                targetPreview.setImageURI(t)
            }
        }
    }

    private fun lite(): FaceSwapper {
        var d = detector
        if (d == null) {
            d = FaceSwapper(applicationContext, File(filesDir, "models"))
            detector = d
        }
        return d
    }

    private fun detectForMulti(uri: Uri) {
        multiRows.removeAllViews()
        multiUris.clear()
        multiThumbs.clear()
        faceBoxes.setFaces(emptyList(), 0, 0)
        statusText.text = getString(R.string.detecting)
        Thread {
            try {
                val bmp = loadBitmap(uri, Enhance.TARGET_SIDE)
                val faces = lite().detect(bmp).sortedBy { it.box.left }
                runOnUiThread {
                    if (!multiMode || targetUri != uri) return@runOnUiThread
                    multiTargetBmp = bmp
                    multiFaces = faces
                    targetPreview.setImageBitmap(bmp)
                    faceBoxes.visibility = View.VISIBLE
                    faceBoxes.setFaces(faces.map { it.box }, bmp.width, bmp.height)
                    if (faces.isEmpty()) {
                        facesInfo.visibility = View.GONE
                        multiRows.visibility = View.GONE
                        statusText.text = getString(R.string.no_face_target)
                    } else {
                        buildMultiRows(bmp, faces)
                        facesInfo.visibility = View.VISIBLE
                        facesInfo.text = getString(R.string.faces_found, faces.size)
                        multiRows.visibility = View.VISIBLE
                        statusText.text = ""
                    }
                }
            } catch (e: Throwable) {
                setStatus(getString(R.string.error_generic, e.toString()))
            }
        }.start()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundOutline(v: View) {
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
    }

    private fun buildMultiRows(bmp: Bitmap, faces: List<FaceInfo>) {
        multiRows.removeAllViews()
        multiUris.clear()
        multiThumbs.clear()
        for ((i, f) in faces.withIndex()) {
            multiUris.add(null)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setBackgroundResource(R.drawable.bg_upload)
            row.setPadding(dp(12), dp(10), dp(12), dp(10))
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            row.layoutParams = lp

            val label = TextView(this)
            label.text = getString(R.string.face_n, i + 1)
            label.setTextColor(Color.WHITE)
            label.layoutParams = LinearLayout.LayoutParams(dp(64), LinearLayout.LayoutParams.WRAP_CONTENT)

            val orig = ImageView(this)
            orig.layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))
            orig.scaleType = ImageView.ScaleType.CENTER_CROP
            val b = f.box
            val mx = (b.width() * 0.15f).toInt()
            val my = (b.height() * 0.15f).toInt()
            val l = max(0, b.left - mx)
            val t = max(0, b.top - my)
            val r = min(bmp.width, b.right + mx)
            val bt = min(bmp.height, b.bottom + my)
            if (r - l > 2 && bt - t > 2) {
                orig.setImageBitmap(Bitmap.createBitmap(bmp, l, t, r - l, bt - t))
            }
            roundOutline(orig)

            val arrow = TextView(this)
            arrow.text = "→"
            arrow.setTextColor(resources.getColor(R.color.accent, theme))
            arrow.textSize = 26f
            arrow.gravity = Gravity.CENTER
            arrow.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

            val add = ImageView(this)
            add.layoutParams = LinearLayout.LayoutParams(dp(72), dp(72))
            add.scaleType = ImageView.ScaleType.CENTER_CROP
            add.setImageResource(R.drawable.ic_upload)
            add.setPadding(dp(14), dp(14), dp(14), dp(14))
            add.setBackgroundColor(0xFF2A2A2A.toInt())
            roundOutline(add)
            add.setOnClickListener {
                pendingIndex = i
                pickMultiFace.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
            multiThumbs.add(add)

            row.addView(label)
            row.addView(orig)
            row.addView(arrow)
            row.addView(add)
            multiRows.addView(row)
        }
    }

    // ---------- Lancement ----------
    private fun startSwap() {
        val t = targetUri
        if (t == null) {
            Toast.makeText(this, R.string.pick_both, Toast.LENGTH_SHORT).show()
            return
        }
        if (!chkRights.isChecked) {
            Toast.makeText(this, R.string.confirm_needed, Toast.LENGTH_SHORT).show()
            return
        }
        if (multiMode) {
            if (multiUris.none { it != null }) {
                Toast.makeText(this, R.string.pick_all_faces, Toast.LENGTH_SHORT).show()
                return
            }
            runMulti(t)
        } else {
            val f = faceUri
            if (f == null) {
                Toast.makeText(this, R.string.pick_both, Toast.LENGTH_SHORT).show()
                return
            }
            runSingle(t, f)
        }
    }

    private fun ensureModels(dir: File) {
        Downloader.ensure(dir, Models.ARCFACE_FILE, Models.ARCFACE_URLS, Models.ARCFACE_MIN) { p ->
            setStatus(getString(R.string.downloading_models, 1, p), p)
        }
        Downloader.ensure(dir, Models.SWAPPER_FILE, Models.SWAPPER_URLS, Models.SWAPPER_MIN) { p ->
            setStatus(getString(R.string.downloading_models, 2, p), p)
        }
        // Amélioration du visage : optionnelle. Si le téléchargement échoue, le swap marche quand même.
        try {
            Downloader.ensure(dir, Models.GFPGAN_FILE, Models.GFPGAN_URLS, Models.GFPGAN_MIN) { p ->
                setStatus(getString(R.string.downloading_enhancer, p), p)
            }
        } catch (e: Exception) {
            enhanceDownloadError = e.toString().take(140)
        }
    }

    private var enhanceDownloadError: String = ""

    private fun enhanceLine(status: String): String {
        var st = status
        if (st.startsWith("NON") && enhanceDownloadError.isNotEmpty()) st += " | " + enhanceDownloadError
        return getString(R.string.enhance_status, st)
    }

    private fun runSingle(t: Uri, f: Uri) {
        btnSwap.isEnabled = false
        resultPreview.setImageDrawable(null)
        btnDownload.visibility = View.GONE
        progressText.visibility = View.GONE

        Thread {
            var swapper: FaceSwapper? = null
            var ok = false
            try {
                val dir = File(filesDir, "models")
                ensureModels(dir)

                beginProgress()
                stage(0, 15, getString(R.string.detecting))
                val targetBmp = loadBitmap(t, Enhance.TARGET_SIDE)
                val sourceBmp = loadBitmap(f)
                swapper = FaceSwapper(applicationContext, dir)

                val targetFaces = swapper.detect(targetBmp)
                if (targetFaces.isEmpty()) {
                    setStatus(getString(R.string.no_face_target))
                    return@Thread
                }
                val sourceFaces = swapper.detect(sourceBmp)
                if (sourceFaces.isEmpty()) {
                    setStatus(getString(R.string.no_face_source))
                    return@Thread
                }

                stage(15, 40, getString(R.string.swapping))
                val latent = swapper.sourceLatent(sourceBmp, sourceFaces[0])
                stage(40, 70, getString(R.string.swapping))
                val swapped = swapper.swap(targetBmp, targetFaces[0], latent)

                stage(70, 90, getString(R.string.step_face))
                val result = swapper.enhanceFace(swapped, targetFaces[0])
                if (result !== swapped) swapped.recycle()

                stage(90, 100, getString(R.string.step_enhance))
                val finalBmp = Enhance.finish(result)
                val where = saveToDownloads(finalBmp)
                showResult(finalBmp)
                ok = true
                endProgress(true)
                setStatus(getString(R.string.done, where) + "\n" + enhanceLine(swapper?.enhanceStatus ?: "?"))
            } catch (e: Throwable) {
                setStatus(getString(R.string.error_generic, e.toString()))
            } finally {
                swapper?.close()
                if (!ok) endProgress(false)
                runOnUiThread { btnSwap.isEnabled = true }
            }
        }.start()
    }

    private fun runMulti(t: Uri) {
        val faces = multiFaces
        val uris = ArrayList(multiUris)
        val targetBmp = multiTargetBmp
        if (targetBmp == null || faces.isEmpty()) {
            Toast.makeText(this, R.string.tap_to_detect, Toast.LENGTH_SHORT).show()
            return
        }
        btnSwap.isEnabled = false
        resultPreview.setImageDrawable(null)
        btnDownload.visibility = View.GONE
        progressText.visibility = View.GONE

        Thread {
            var swapper: FaceSwapper? = null
            var ok = false
            try {
                val dir = File(filesDir, "models")
                ensureModels(dir)

                beginProgress()
                stage(0, 8, getString(R.string.step_models))
                swapper = FaceSwapper(applicationContext, dir)

                val jobs = faces.indices.filter { uris[it] != null }
                var current: Bitmap = targetBmp
                val total = jobs.size
                for ((k, idx) in jobs.withIndex()) {
                    val from = 8 + (82 * k) / total
                    val to = 8 + (82 * (k + 1)) / total
                    stage(from, to, getString(R.string.step_swap_n, k + 1, total))
                    val srcBmp = loadBitmap(uris[idx]!!)
                    val srcFaces = swapper.detect(srcBmp)
                    if (srcFaces.isEmpty()) {
                        setStatus(getString(R.string.no_face_source) + " (" + getString(R.string.face_n, idx + 1) + ")")
                        return@Thread
                    }
                    val latent = swapper.sourceLatent(srcBmp, srcFaces[0])
                    val swapped = swapper.swap(current, faces[idx], latent)
                    if (current !== targetBmp) current.recycle()
                    val next = swapper.enhanceFace(swapped, faces[idx])
                    if (next !== swapped) swapped.recycle()
                    current = next
                }

                stage(90, 100, getString(R.string.step_enhance))
                val finalBmp = Enhance.finish(current)
                val where = saveToDownloads(finalBmp)
                showResult(finalBmp)
                ok = true
                endProgress(true)
                setStatus(getString(R.string.done, where) + "\n" + enhanceLine(swapper?.enhanceStatus ?: "?"))
            } catch (e: Throwable) {
                setStatus(getString(R.string.error_generic, e.toString()))
            } finally {
                swapper?.close()
                if (!ok) endProgress(false)
                runOnUiThread { btnSwap.isEnabled = true }
            }
        }.start()
    }

    override fun onDestroy() {
        tickRunning = false
        ui.removeCallbacks(ticker)
        detector?.close()
        super.onDestroy()
    }

    private fun loadBitmap(uri: Uri, maxSide: Int = 2048): Bitmap {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        val bmp = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalStateException("decode failed")

        var degrees = 0f
        try {
            contentResolver.openInputStream(uri).use { s ->
                if (s != null) {
                    val exif = ExifInterface(s)
                    degrees = when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                }
            }
        } catch (e: Exception) {
            degrees = 0f
        }
        if (degrees != 0f) {
            val m = Matrix()
            m.postRotate(degrees)
            return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        return bmp
    }

    private fun showResult(finalBmp: Bitmap) {
        val prev = Enhance.preview(finalBmp)
        runOnUiThread {
            resultPreview.setImageBitmap(prev)
            btnDownload.visibility = View.VISIBLE
            scroll.postDelayed({
                scroll.smoothScrollTo(0, btnDownload.top - dp(16))
            }, 250)
        }
    }

    private fun openSaved() {
        val u = lastSavedUri
        if (u == null) {
            Toast.makeText(this, R.string.pick_both, Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, getString(R.string.saved_in, lastSavedPath), Toast.LENGTH_LONG).show()
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(u, "image/jpeg")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
        }
    }

    /** Crée Download/Klaws Face/Videos une seule fois (dossier prêt pour la future étape vidéo). */
    private fun ensureVideosFolder() {
        val prefs = getSharedPreferences("klaws", MODE_PRIVATE)
        if (prefs.getBoolean("videos_folder", false)) return
        try {
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, "Videos.txt")
            v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Klaws Face/Videos")
            val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
            if (u != null) {
                contentResolver.openOutputStream(u)?.use { it.write("Klaws Face - videos".toByteArray()) }
                prefs.edit().putBoolean("videos_folder", true).apply()
            }
        } catch (e: Exception) {
        }
    }

    private fun saveToDownloads(bmp: Bitmap): String {
        val name = "KlawsFace_" + System.currentTimeMillis() + ".jpg"
        if (Build.VERSION.SDK_INT >= 29) {
            ensureVideosFolder()
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            v.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/Klaws Face/Photos")
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("save failed")
            contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            lastSavedUri = uri
            lastSavedPath = "Download/Klaws Face/Photos/$name"
            return lastSavedPath
        } else {
            val dir = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "Klaws Face/Photos")
            dir.mkdirs()
            val file = File(dir, name)
            file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            lastSavedUri = Uri.fromFile(file)
            lastSavedPath = file.path
            return file.path
        }
    }
}
