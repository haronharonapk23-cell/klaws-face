package com.klaws.face

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class FaceInfo(val box: Rect, val kps: FloatArray)

class FaceSwapper(private val context: Context, private val modelsDir: File) {

    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setMinFaceSize(0.05f)
            .build()
    )

    private val arc = floatArrayOf(
        38.2946f, 51.6963f,
        73.5318f, 51.5014f,
        56.0252f, 71.7366f,
        41.5493f, 92.3655f,
        70.7299f, 92.2041f
    )

    private var emapCache: FloatArray? = null
    private var arcSess: OrtSession? = null
    private var swapSess: OrtSession? = null
    private var gfpSess: OrtSession? = null

    /** Résultat du dernier essai d'amélioration du visage (affiché à l'écran). */
    @Volatile var enhanceStatus: String = "?"

    // Gabarit FFHQ 512 (5 points) utilisé par GFPGAN
    private val ffhq512 = floatArrayOf(
        192.98138f, 239.94708f,
        318.90277f, 240.1936f,
        256.63416f, 314.01935f,
        201.26117f, 371.41043f,
        313.08905f, 370.38214f
    )

    private fun arcSession(): OrtSession {
        var s = arcSess
        if (s == null) {
            s = env.createSession(File(modelsDir, Models.ARCFACE_FILE).absolutePath, OrtSession.SessionOptions())
            arcSess = s
        }
        return s!!
    }

    private fun swapSession(): OrtSession {
        var s = swapSess
        if (s == null) {
            s = env.createSession(File(modelsDir, Models.SWAPPER_FILE).absolutePath, OrtSession.SessionOptions())
            swapSess = s
        }
        return s!!
    }

    fun close() {
        detector.close()
        try { arcSess?.close() } catch (e: Exception) { }
        try { swapSess?.close() } catch (e: Exception) { }
        try { gfpSess?.close() } catch (e: Exception) { }
        arcSess = null
        swapSess = null
        gfpSess = null
    }

    // ---------- Détection (toutes les orientations) ----------
    private fun iou(a: Rect, b: Rect): Float {
        val l = max(a.left, b.left)
        val t = max(a.top, b.top)
        val r = min(a.right, b.right)
        val bt = min(a.bottom, b.bottom)
        if (r <= l || bt <= t) return 0f
        val inter = (r - l).toFloat() * (bt - t)
        val u = a.width().toFloat() * a.height() + b.width().toFloat() * b.height() - inter
        return if (u <= 0f) 0f else inter / u
    }

    private fun mergeFaces(into: ArrayList<FaceInfo>, add: List<FaceInfo>) {
        for (f in add) {
            var dup = false
            for (e in into) {
                val cfx = f.box.centerX(); val cfy = f.box.centerY()
                val cex = e.box.centerX(); val cey = e.box.centerY()
                val inside = e.box.contains(cfx, cfy) || f.box.contains(cex, cey)
                if (inside || iou(e.box, f.box) > 0.25f) { dup = true; break }
            }
            if (!dup) into.add(f)
        }
    }

    /** Détecte les visages même à l'envers ou penchés (0°, 180°, 90°, 270° puis diagonales). */
    fun detect(bmp: Bitmap): List<FaceInfo> {
        val big = max(bmp.width, bmp.height)
        val s = if (big > 1280) 1280f / big else 1f
        val small = if (s < 1f) Bitmap.createScaledBitmap(
            bmp, (bmp.width * s).toInt().coerceAtLeast(1), (bmp.height * s).toInt().coerceAtLeast(1), true
        ) else bmp
        val found = ArrayList<FaceInfo>()
        try {
            for (a in intArrayOf(0, 180, 90, 270, 45, 315, 135, 225)) {
                mergeFaces(found, detectAt(small, a.toFloat(), s))
            }
            if (found.isEmpty()) {
                // visages très penchés (gymnastique, saltos) : pas plus fins
                for (a in intArrayOf(22, 338, 68, 292, 112, 248, 158, 202)) {
                    mergeFaces(found, detectAt(small, a.toFloat(), s))
                    if (found.isNotEmpty()) break
                }
            }
        } finally {
            if (small !== bmp) small.recycle()
        }
        return found.sortedByDescending { it.box.width() * it.box.height() }
    }

    private fun detectAt(small: Bitmap, deg: Float, s: Float): List<FaceInfo> {
        val m = Matrix()
        val rb: Bitmap
        if (deg == 0f) {
            rb = small
        } else {
            val w = small.width
            val h = small.height
            val rad = Math.toRadians(deg.toDouble())
            val c = abs(Math.cos(rad))
            val sn = abs(Math.sin(rad))
            val nw = (w * c + h * sn).toInt().coerceAtLeast(1)
            val nh = (w * sn + h * c).toInt().coerceAtLeast(1)
            m.postTranslate(-w / 2f, -h / 2f)
            m.postRotate(deg)
            m.postTranslate(nw / 2f, nh / 2f)
            rb = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888)
            val cv = Canvas(rb)
            cv.drawColor(Color.BLACK)
            cv.drawBitmap(small, m, Paint(Paint.FILTER_BITMAP_FLAG))
        }
        val inv = Matrix()
        m.invert(inv)
        val list = ArrayList<FaceInfo>()
        try {
            val faces = Tasks.await(detector.process(InputImage.fromBitmap(rb, 0)))
            for (f in faces) {
                val le = f.getLandmark(FaceLandmark.LEFT_EYE)?.position
                val re = f.getLandmark(FaceLandmark.RIGHT_EYE)?.position
                val nose = f.getLandmark(FaceLandmark.NOSE_BASE)?.position
                val ml = f.getLandmark(FaceLandmark.MOUTH_LEFT)?.position
                val mr = f.getLandmark(FaceLandmark.MOUTH_RIGHT)?.position
                if (le == null || re == null || nose == null || ml == null || mr == null) continue
                // L'ordre gauche/droite est fixé dans le repère redressé du visage.
                val eyes = listOf(le, re).sortedBy { it.x }
                val mouth = listOf(ml, mr).sortedBy { it.x }
                val pts = floatArrayOf(
                    eyes[0].x, eyes[0].y,
                    eyes[1].x, eyes[1].y,
                    nose.x, nose.y,
                    mouth[0].x, mouth[0].y,
                    mouth[1].x, mouth[1].y
                )
                inv.mapPoints(pts)
                for (i in pts.indices) pts[i] = pts[i] / s
                val rf = RectF(f.boundingBox)
                inv.mapRect(rf)
                val box = Rect(
                    (rf.left / s).toInt(), (rf.top / s).toInt(),
                    (rf.right / s).toInt(), (rf.bottom / s).toInt()
                )
                list.add(FaceInfo(box, pts))
            }
        } finally {
            if (rb !== small) rb.recycle()
        }
        return list
    }

    // ---------- Alignement ----------
    private fun similarity(src: FloatArray, dst: FloatArray): Matrix {
        val n = 5
        var sx = 0f
        var sy = 0f
        var dx = 0f
        var dy = 0f
        for (i in 0 until n) {
            sx += src[2 * i]; sy += src[2 * i + 1]
            dx += dst[2 * i]; dy += dst[2 * i + 1]
        }
        sx /= n; sy /= n; dx /= n; dy /= n
        var num1 = 0f
        var num2 = 0f
        var den = 0f
        for (i in 0 until n) {
            val xs = src[2 * i] - sx
            val ys = src[2 * i + 1] - sy
            val xd = dst[2 * i] - dx
            val yd = dst[2 * i + 1] - dy
            num1 += xs * xd + ys * yd
            num2 += xs * yd - ys * xd
            den += xs * xs + ys * ys
        }
        val a = num1 / den
        val b = num2 / den
        val tx = dx - (a * sx - b * sy)
        val ty = dy - (b * sx + a * sy)
        val m = Matrix()
        m.setValues(floatArrayOf(a, -b, tx, b, a, ty, 0f, 0f, 1f))
        return m
    }

    private fun align(bmp: Bitmap, kps: FloatArray, size: Int, shiftX: Float): Pair<Bitmap, Matrix> {
        val dst = FloatArray(10)
        for (i in 0 until 10) {
            dst[i] = if (i % 2 == 0) arc[i] + shiftX else arc[i]
        }
        val m = similarity(kps, dst)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(bmp, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return Pair(out, m)
    }

    private fun toChw(bmp: Bitmap, mean: Float, std: Float): FloatArray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val out = FloatArray(3 * w * h)
        val plane = w * h
        for (i in px.indices) {
            val p = px[i]
            out[i] = (((p shr 16) and 255) - mean) / std
            out[plane + i] = (((p shr 8) and 255) - mean) / std
            out[2 * plane + i] = ((p and 255) - mean) / std
        }
        return out
    }

    private fun normalize(v: FloatArray): FloatArray {
        var s = 0f
        for (x in v) s += x * x
        val n = sqrt(s)
        val out = FloatArray(v.size)
        for (i in v.indices) out[i] = v[i] / n
        return out
    }

    private fun readFloats(t: OnnxTensor): FloatArray {
        val fb = t.floatBuffer
        val arr = FloatArray(fb.remaining())
        fb.get(arr)
        return arr
    }

    // ---------- Visage source -> vecteur ----------
    fun sourceLatent(src: Bitmap, face: FaceInfo): FloatArray {
        val (al, _) = align(src, face.kps, 112, 0f)
        val sess = arcSession()
        var emb = FloatArray(0)
        try {
            val name = sess.inputNames.iterator().next()
            val tensor = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(toChw(al, 127.5f, 127.5f)), longArrayOf(1, 3, 112, 112)
            )
            try {
                val res = sess.run(mapOf(name to tensor))
                try {
                    emb = normalize(readFloats(res[0] as OnnxTensor))
                } finally {
                    res.close()
                }
            } finally {
                tensor.close()
            }
        } finally {
        }

        val emapArr = emapCache ?: run {
            val bytes = context.assets.open("emap.bin").readBytes()
            val emap = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
            val a = FloatArray(512 * 512)
            emap.get(a)
            emapCache = a
            a
        }
        val lat = FloatArray(512)
        for (j in 0 until 512) {
            var s = 0f
            for (i in 0 until 512) s += emb[i] * emapArr[i * 512 + j]
            lat[j] = s
        }
        return normalize(lat)
    }

    // ---------- Adaptation couleur de peau + lumière ----------
    private fun lumaOf(r: Float, g: Float, b: Float) = 0.299f * r + 0.587f * g + 0.114f * b
    private fun cbOf(r: Float, g: Float, b: Float) = 128f - 0.168736f * r - 0.331264f * g + 0.5f * b
    private fun crOf(r: Float, g: Float, b: Float) = 128f + 0.5f * r - 0.418688f * g - 0.081312f * b

    /** Ajuste le visage généré à la teinte et à la lumière du visage d'origine (zone du masque). */
    private fun matchSkin(fake: FloatArray, ref: IntArray, mask: FloatArray, plane: Int) {
        val sf = DoubleArray(3); val qf = DoubleArray(3)
        val st = DoubleArray(3); val qt = DoubleArray(3)
        var n = 0
        for (i in 0 until plane) {
            val p = ref[i]
            if (mask[i] < 0.6f || ((p ushr 24) and 255) < 200) continue
            val fr = fake[i]; val fg = fake[plane + i]; val fb = fake[2 * plane + i]
            val tr = ((p shr 16) and 255).toFloat(); val tg = ((p shr 8) and 255).toFloat(); val tb = (p and 255).toFloat()
            val f0 = lumaOf(fr, fg, fb).toDouble(); val f1 = cbOf(fr, fg, fb).toDouble(); val f2 = crOf(fr, fg, fb).toDouble()
            val t0 = lumaOf(tr, tg, tb).toDouble(); val t1 = cbOf(tr, tg, tb).toDouble(); val t2 = crOf(tr, tg, tb).toDouble()
            sf[0] += f0; sf[1] += f1; sf[2] += f2
            qf[0] += f0 * f0; qf[1] += f1 * f1; qf[2] += f2 * f2
            st[0] += t0; st[1] += t1; st[2] += t2
            qt[0] += t0 * t0; qt[1] += t1 * t1; qt[2] += t2 * t2
            n++
        }
        if (n < 300) return
        val mf = DoubleArray(3) { sf[it] / n }
        val mt = DoubleArray(3) { st[it] / n }
        val sdF = sqrt(max(1e-3, qf[0] / n - mf[0] * mf[0]))
        val sdT = sqrt(max(1e-3, qt[0] / n - mt[0] * mt[0]))
        val ratio = (sdT / sdF).coerceIn(0.8, 1.25).toFloat()
        for (i in 0 until plane) {
            val r = fake[i]; val g = fake[plane + i]; val b = fake[2 * plane + i]
            val y = (lumaOf(r, g, b) - mf[0].toFloat()) * ratio + mt[0].toFloat()
            val cb = cbOf(r, g, b) - mf[1].toFloat() + mt[1].toFloat()
            val cr = crOf(r, g, b) - mf[2].toFloat() + mt[2].toFloat()
            fake[i] = (y + 1.402f * (cr - 128f)).coerceIn(0f, 255f)
            fake[plane + i] = (y - 0.344136f * (cb - 128f) - 0.714136f * (cr - 128f)).coerceIn(0f, 255f)
            fake[2 * plane + i] = (y + 1.772f * (cb - 128f)).coerceIn(0f, 255f)
        }
    }

    // ---------- Changement du visage ----------
    fun swap(target: Bitmap, face: FaceInfo, latent: FloatArray): Bitmap {
        val (al, m) = align(target, face.kps, 128, 8f)
        val sess = swapSession()
        var outFloats = FloatArray(0)
        try {
            val names = sess.inputNames.toList()
            val tTarget = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(toChw(al, 0f, 255f)), longArrayOf(1, 3, 128, 128)
            )
            val tSource = OnnxTensor.createTensor(
                env, FloatBuffer.wrap(latent), longArrayOf(1, 512)
            )
            try {
                val res = sess.run(mapOf(names[0] to tTarget, names[1] to tSource))
                try {
                    outFloats = readFloats(res[0] as OnnxTensor)
                } finally {
                    res.close()
                }
            } finally {
                tTarget.close()
                tSource.close()
            }
        } finally {
        }

        val size = 128
        val plane = size * size

        // masque doux (ellipse, bord large pour éviter les traces autour de la bouche et du menton)
        val mask = FloatArray(plane)
        for (y in 0 until size) {
            for (x in 0 until size) {
                val dx = (x - 64f) / 44f
                val dy = (y - 70f) / 54f
                val d = sqrt(dx * dx + dy * dy)
                mask[y * size + x] = ((1f - d) / 0.35f).coerceIn(0f, 1f)
            }
        }

        // visage généré en 0..255 puis adaptation couleur
        val fake255 = FloatArray(3 * plane)
        for (i in 0 until 3 * plane) fake255[i] = (outFloats[i] * 255f).coerceIn(0f, 255f)
        val refPx = IntArray(plane)
        al.getPixels(refPx, 0, size, 0, 0, size, size)
        al.recycle()
        matchSkin(fake255, refPx, mask, plane)

        val px = IntArray(plane)
        for (i in 0 until plane) {
            val r = fake255[i].toInt()
            val g = fake255[plane + i].toInt()
            val b = fake255[2 * plane + i].toInt()
            val a = (mask[i] * 255f).toInt()
            px[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        val fake = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        fake.setPixels(px, 0, size, 0, 0, size, size)

        val inv = Matrix()
        m.invert(inv)
        val result = target.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(result)
        c.drawBitmap(fake, inv, Paint(Paint.FILTER_BITMAP_FLAG))
        fake.recycle()
        return result
    }

    // ---------- Amélioration du visage (GFPGAN) ----------
    private fun gfpSession(): OrtSession {
        var s = gfpSess
        if (s == null) {
            s = env.createSession(File(modelsDir, Models.GFPGAN_FILE).absolutePath, OrtSession.SessionOptions())
            gfpSess = s
        }
        return s!!
    }

    /**
     * Rend le visage net (la sortie du swap est en 128 px, donc floue).
     * Si le modèle manque ou si quoi que ce soit échoue, l'image reçue est rendue telle quelle.
     */
    fun enhanceFace(img: Bitmap, face: FaceInfo, strength: Float = 1.0f): Bitmap {
        val f = File(modelsDir, Models.GFPGAN_FILE)
        if (!f.exists()) {
            enhanceStatus = "NON — modèle absent / النموذج غير موجود"
            return img
        }
        if (f.length() < Models.GFPGAN_MIN) {
            enhanceStatus = "NON — modèle incomplet (" + (f.length() / 1000000) + " Mo) / النموذج ناقص"
            return img
        }
        return try {
            enhanceInner(img, face.kps, strength)
        } catch (e: Throwable) {
            enhanceStatus = "NON — erreur : " + e.toString().take(140)
            img
        }
    }

    private fun enhanceInner(img: Bitmap, kps: FloatArray, strength: Float): Bitmap {
        val size = 512
        val plane = size * size
        val m = similarity(kps, ffhq512)

        val crop = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(crop).drawBitmap(img, m, Paint(Paint.FILTER_BITMAP_FLAG))
        val input = toChw(crop, 127.5f, 127.5f)   // RGB, de -1 à 1
        val refPx = IntArray(plane)
        crop.getPixels(refPx, 0, size, 0, 0, size, size)
        crop.recycle()

        val sess = gfpSession()
        val name = sess.inputNames.iterator().next()
        val tensor = OnnxTensor.createTensor(
            env, FloatBuffer.wrap(input), longArrayOf(1, 3, 512, 512)
        )
        var out = FloatArray(0)
        try {
            val res = sess.run(mapOf(name to tensor))
            try {
                out = readFloats(res[0] as OnnxTensor)
            } finally {
                res.close()
            }
        } finally {
            tensor.close()
        }
        if (out.size != 3 * plane) {
            enhanceStatus = "NON — sortie inattendue (" + out.size + ")"
            return img
        }

        // masque doux en ellipse autour du visage
        val mask = FloatArray(plane)
        for (y in 0 until size) {
            for (x in 0 until size) {
                val dx = (x - 256f) / 150f
                val dy = (y - 300f) / 185f
                val d = sqrt(dx * dx + dy * dy)
                mask[y * size + x] = ((1f - d) / 0.3f).coerceIn(0f, 1f)
            }
        }

        val fake = FloatArray(3 * plane)
        for (i in 0 until 3 * plane) fake[i] = ((out[i] * 0.5f + 0.5f) * 255f).coerceIn(0f, 255f)

        // contrôle de sécurité : si la lumière change trop, la sortie est suspecte -> on ne touche pas l'image
        var sumIn = 0.0
        var sumOut = 0.0
        var cnt = 0
        for (i in 0 until plane) {
            if (mask[i] < 0.6f) continue
            val p = refPx[i]
            if (((p ushr 24) and 255) < 200) continue
            sumIn += lumaOf(((p shr 16) and 255).toFloat(), ((p shr 8) and 255).toFloat(), (p and 255).toFloat())
            sumOut += lumaOf(fake[i], fake[plane + i], fake[2 * plane + i])
            cnt++
        }
        if (cnt < 300) {
            enhanceStatus = "NON — visage trop petit / الوجه صغير جدًا"
            return img
        }
        val diff = abs(sumOut / cnt - sumIn / cnt)
        if (diff.isNaN() || diff > 55.0) {
            enhanceStatus = "NON — sortie rejetée (luminosité " + diff.toInt() + ")"
            return img
        }

        matchSkin(fake, refPx, mask, plane)

        val px = IntArray(plane)
        for (i in 0 until plane) {
            val r = fake[i].toInt().coerceIn(0, 255)
            val g = fake[plane + i].toInt().coerceIn(0, 255)
            val b = fake[2 * plane + i].toInt().coerceIn(0, 255)
            val a = (mask[i] * strength * 255f).toInt().coerceIn(0, 255)
            px[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        val faceBmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        faceBmp.setPixels(px, 0, size, 0, 0, size, size)

        val inv = Matrix()
        m.invert(inv)
        val result = img.copy(Bitmap.Config.ARGB_8888, true)
        Canvas(result).drawBitmap(faceBmp, inv, Paint(Paint.FILTER_BITMAP_FLAG))
        faceBmp.recycle()
        enhanceStatus = "OUI ✅ / نعم ✅"
        return result
    }
}
